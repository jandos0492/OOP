let task3 = new List(['one', 'two', 'three', 'four']);
document.body.appendChild(task3.render());


let task6 = new List2(['one', 'two', 'three', 'four', "five", "six"], "task6");
document.body.appendChild(task6.render());

let task8 = new List3(['one', 'two', 'three', 'four', "five", "six", "seven"], ['text-center', 'bold', 'text-red']);
document.body.appendChild(task8.render());