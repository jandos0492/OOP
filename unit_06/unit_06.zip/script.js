//task2

console.log(Validate.isNumber("hello"));
console.log(Validate.isNumber(5));

//task3

console.log(Validate.isInt(10));
console.log(Validate.isInt(10.5));

//task4

console.log(Validate.isFloat(10));
console.log(Validate.isFloat(10.5));

//task5

console.log(Validate.isChar("hello"));
console.log(Validate.isChar("H"));

//task6

console.log(Validate.isString("hello"));
console.log(Validate.isString(["hello"]));

//task7

console.log(Validate.isBoolean(0));
console.log(Validate.isBoolean(true));

//task8

console.log(Validate.isArray([1, 2, "Hello"]));
console.log(Validate.isArray("true"));

//task9

console.log(Validate.toMoney(258239871));

